package ru.doov.r17

import android.app.Activity
import android.os.Bundle
import android.view.*
import android.widget.*
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.content.Intent
import android.provider.Settings
import android.net.Uri
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var clock: TextView
    private val blue = Color.rgb(0, 0, 0)
    private val panel = Color.rgb(8, 8, 8)
    private val accent = Color.rgb(0, 120, 220)
    private data class AppItem(val title: String, val icon: Int, val intent: Intent)
    private val apps by lazy { listOf(
        AppItem("Вызовы", R.drawable.ic_call, Intent(Intent.ACTION_DIAL)),
        AppItem("Контакты", R.drawable.ic_contacts, Intent(Intent.ACTION_VIEW, Uri.parse("content://contacts/people"))),
        AppItem("Сообщения", R.drawable.ic_messages, Intent(Intent.ACTION_MAIN).addCategory("android.intent.category.APP_MESSAGING")),
        AppItem("Камера", R.drawable.ic_camera, Intent("android.media.action.IMAGE_CAPTURE")),
        AppItem("Аудиоплеер", R.drawable.ic_music, Intent(Intent.ACTION_MAIN).addCategory("android.intent.category.APP_MUSIC")),
        AppItem("FM-радио", R.drawable.ic_radio, Intent(Intent.ACTION_MAIN).addCategory("android.intent.category.APP_RADIO")),
        AppItem("Инструменты", R.drawable.ic_tools, Intent(Intent.ACTION_GET_CONTENT).setType("*/*")),
        AppItem("Настройки", R.drawable.ic_settings, Intent(Settings.ACTION_SETTINGS)),
        AppItem("Интернет", R.drawable.ic_internet, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com")))
    ) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
            or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            or View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
        showHome()
    }

    private fun base() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.BLACK) }
        setContentView(root)
    }
    private fun blueBar(text: String): TextView = TextView(this).apply {
        this.text=text; textSize=23f; setTextColor(Color.WHITE); gravity=Gravity.CENTER
        setPadding(8,10,8,10); setBackgroundColor(panel)
        typeface=Typeface.create("sans-serif",Typeface.NORMAL)
    }
    private fun footer(left: String, right: String, action: () -> Unit) {
        val row=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; setBackgroundColor(blue) }
        row.addView(TextView(this).apply { text=left; textSize=21f; setTextColor(-1); gravity=Gravity.CENTER_VERTICAL; setPadding(18,10,8,10) }, LinearLayout.LayoutParams(0,-2,1f))
        row.addView(TextView(this).apply { text=right; textSize=21f; setTextColor(-1); gravity=Gravity.CENTER_VERTICAL; setPadding(8,10,18,10) })
        row.setOnClickListener { action() }; root.addView(row)
    }
    private fun showHome() {
        base()
        val frame=FrameLayout(this)
        val bg=ImageView(this).apply { setImageResource(R.drawable.wallpaper); scaleType=ImageView.ScaleType.CENTER_CROP }
        frame.addView(bg,FrameLayout.LayoutParams(-1,-1))
        val overlay=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER_HORIZONTAL }
        val status=TextView(this).apply { text="▮▮▮  GSM                                      ♫  ▰"; textSize=16f; setTextColor(-1); setPadding(16,12,16,8); setShadowLayer(2f,1f,1f,Color.BLACK) }
        clock=TextView(this).apply { textSize=62f; setTextColor(-1); gravity=Gravity.CENTER; setShadowLayer(3f,2f,2f,Color.BLACK); setPadding(0,36,0,0) }
        val date=TextView(this).apply { text=SimpleDateFormat("dd.MM.yyyy",Locale.getDefault()).format(Date())+"\n"+SimpleDateFormat("EEE",Locale("ru")).format(Date()); textSize=23f; setTextColor(-1); gravity=Gravity.CENTER; setShadowLayer(2f,1f,1f,Color.BLACK) }
        overlay.addView(status); overlay.addView(clock); overlay.addView(date)
        frame.addView(overlay,FrameLayout.LayoutParams(-1,-2,Gravity.TOP))
        root.addView(frame,LinearLayout.LayoutParams(-1,0,1f))
        val handler=android.os.Handler(mainLooper)
        val tick=object:Runnable { override fun run(){ clock.text=SimpleDateFormat("HH:mm",Locale.getDefault()).format(Date()); handler.postDelayed(this,1000) } }
        handler.post(tick)
        footer("Меню","Контакты") { showMenu() }
        frame.setOnClickListener { showMenu() }
    }
    private fun showMenu() {
        base()
        root.addView(blueBar("Меню"))
        val grid=GridLayout(this).apply { columnCount=3; rowCount=3; setBackgroundColor(Color.BLACK) }
        apps.forEachIndexed { i,item ->
            val cell=LinearLayout(this).apply {
                orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER; setPadding(4,8,4,8)
                background=GradientDrawable().apply { setColor(Color.BLACK); setStroke(1,Color.rgb(45,45,45)) }
                val icon=ImageView(this@MainActivity).apply { setImageResource(item.icon); scaleType=ImageView.ScaleType.FIT_CENTER }
                addView(icon,LinearLayout.LayoutParams(72,72))
                addView(TextView(this@MainActivity).apply { text=item.title; textSize=15f; gravity=Gravity.CENTER; setTextColor(Color.WHITE) })
                setOnClickListener { launch(item.intent) }
            }
            grid.addView(cell,GridLayout.LayoutParams().apply { width=0; height=0; columnSpec=GridLayout.spec(i%3,1f); rowSpec=GridLayout.spec(i/3,1f) })
        }
        root.addView(grid,LinearLayout.LayoutParams(-1,0,1f))
        footer("Выбрать","Назад") { showHome() }
    }
    private fun launch(intent: Intent) {
        try { startActivity(intent) }
        catch (_: Exception) { Toast.makeText(this,"Приложение не найдено",Toast.LENGTH_SHORT).show() }
    }
    override fun onBackPressed(){ showHome() }
}
